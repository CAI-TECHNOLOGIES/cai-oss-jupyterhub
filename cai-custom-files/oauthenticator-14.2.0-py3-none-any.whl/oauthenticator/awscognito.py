raise ImportError("AWS Cognito can be configured via GenericOAuthenticator")
