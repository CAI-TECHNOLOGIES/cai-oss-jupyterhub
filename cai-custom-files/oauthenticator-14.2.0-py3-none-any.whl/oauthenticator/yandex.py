raise ImportError("Yandex can be configured via GenericOAuthenticator")
