raise ImportError("Azure AD B2C can be configured via AzureAdOAuthenticator")
